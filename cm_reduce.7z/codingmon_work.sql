use codingmondb;
show tables;
desc codingmon_security;
desc codingmon_member;
desc codingmon_member_info;
desc codingmon_subject;
desc codingmon_region;
desc codingmon_security;
desc codingmon_job;
desc codingmon_info_job;
desc codingmon_member_region;
desc codingmon_member_subject;


ALTER TABLE codingmon_member MODIFY cm_pw varchar(255) not null;
ALTER TABLE codingmon_subject MODIFY cs_name varchar(100) UNIQUE;
ALTER TABLE codingmon_region MODIFY cr_name varchar(50) UNIQUE;



SELECT * FROM codingmon_member;
SELECT * FROM codingmon_member_info;
SELECT * FROM codingmon_info_job;
SELECT * FROM codingmon_member_region;
SELECT * FROM codingmon_member_subject;
SELECT * FROM codingmon_member_subject WHERE cms_owner_num=1 ORDER BY cms_category ASC, cms_code DESC;
SELECT * FROM codingmon_job;
SELECT * FROM codingmon_region;
SELECT * FROM codingmon_subject;

DELETE FROM codingmon_member WHERE cm_num=1;

UPDATE codingmon_job SET cj_name='풀 스택' WHERE cj_code=3;


INSERT INTO codingmon_info_job VALUES(1,1);

DROP TABLE codingmon_security;

CREATE TABLE codingmon_passcode(
	cpc_email varchar(50) not null, 
	cpc_code char(5) not null,
	PRIMARY KEY (cpc_email)
);

SELECT * FROM codingmon_passcode;
DESC codingmon_passcode;

DELETE FROM codingmon_member WHERE cm_num=8;

DELETE FROM codingmon_region WHERE cr_code=1;
SELECT * FROM codingmon_region;
INSERT INTO codingmon_region VALUES(1,'서울특별시');
INSERT INTO codingmon_region VALUES(2,'부산광역시');
INSERT INTO codingmon_region VALUES(3,'대구광역시');
INSERT INTO codingmon_region VALUES(4,'인천광역시');
INSERT INTO codingmon_region VALUES(5,'광주광역시');
INSERT INTO codingmon_region VALUES(6,'대전광역시');
INSERT INTO codingmon_region VALUES(7,'울산광역시');
INSERT INTO codingmon_region VALUES(8,'세종특별자치시');
INSERT INTO codingmon_region VALUES(9,'경기도');
INSERT INTO codingmon_region VALUES(10,'강원도');
INSERT INTO codingmon_region VALUES(11,'충청북도');
INSERT INTO codingmon_region VALUES(12,'충청남도');
INSERT INTO codingmon_region VALUES(13,'전라북도');
INSERT INTO codingmon_region VALUES(14,'전라남도');
INSERT INTO codingmon_region VALUES(15,'경상북도');
INSERT INTO codingmon_region VALUES(16,'경상남도');
INSERT INTO codingmon_region VALUES(17,'제주특별시');
INSERT INTO codingmon_region VALUES(99,'전국');
INSERT INTO codingmon_region VALUES(100,'해외');

ALTER TABLE codingmon_subject ADD cs_category INT NOT NULL;

ALTER TABLE codingmon_subject DROP cs_category;



INSERT INTO codingmon_subject VALUES(1,'JAVA',1);
INSERT INTO codingmon_subject VALUES(2,'Spring',1);
INSERT INTO codingmon_subject VALUES(3,'전자정부표준',1);
INSERT INTO codingmon_subject VALUES(11,'C',2);
INSERT INTO codingmon_subject VALUES(12,'C++',2);
INSERT INTO codingmon_subject VALUES(13,'C#',2);
INSERT INTO codingmon_subject VALUES(21,'Vanila JS',3);
INSERT INTO codingmon_subject VALUES(22,'Vue',3);
INSERT INTO codingmon_subject VALUES(23,'Angular',3);
INSERT INTO codingmon_subject VALUES(24,'React',3);
INSERT INTO codingmon_subject VALUES(31,'Python',4);
INSERT INTO codingmon_subject VALUES(32,'Flask',4);
INSERT INTO codingmon_subject VALUES(33,'Django',4);
INSERT INTO codingmon_subject VALUES(91,'Ruby',5);

INSERT INTO codingmon_job VALUES(1, '프론트엔드');
INSERT INTO codingmon_job VALUES(2, '백엔드');
INSERT INTO codingmon_job VALUES(3, '풀스택');
INSERT INTO codingmon_job VALUES(4, '모바일');
INSERT INTO codingmon_job VALUES(5, '데이터&머신러닝 전문가');
INSERT INTO codingmon_job VALUES(6, '데스크탑 어플리케이션');
INSERT INTO codingmon_job VALUES(7, '게임');
INSERT INTO codingmon_job VALUES(8, '임베디드 어플리케이션');
INSERT INTO codingmon_job VALUES(101, '시스템 관리자');
INSERT INTO codingmon_job VALUES(102, 'CEO/CTO');
INSERT INTO codingmon_job VALUES(103, '제품 또는 기술 매니저');
INSERT INTO codingmon_job VALUES(104, '교육가');
INSERT INTO codingmon_job VALUES(105, '학생');
INSERT INTO codingmon_job VALUES(999, '기타');

SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num;

SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_info_job ON codingmon_member_info.cmi_owner_num=codingmon_info_job.cij_owner_num;
SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_region ON codingmon_member_info.cmi_owner_num=codingmon_member_region.cmr_owner_num;
SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_subject ON codingmon_member_info.cmi_owner_num=codingmon_member_subject.cms_owner_num;

(SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_info_job ON codingmon_member_info.cmi_owner_num=codingmon_info_job.cij_owner_num) UNION (SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_region ON codingmon_member_info.cmi_owner_num=codingmon_member_region.cmr_owner_num) UNION (SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_subject ON codingmon_member_info.cmi_owner_num=codingmon_member_subject.cms_owner_num);



SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_info_job ON codingmon_member_info.cmi_owner_num=codingmon_info_job.cij_owner_num INNER JOIN codingmon_job ON codingmon_info_job.cij_code=codingmon_job.cj_code;
SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_region ON codingmon_member_info.cmi_owner_num=codingmon_member_region.cmr_owner_num INNER JOIN codingmon_region ON codingmon_member_region.cmr_code=codingmon_region.cr_code;
SELECT * FROM codingmon_member INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num INNER JOIN codingmon_member_subject ON codingmon_member_info.cmi_owner_num=codingmon_member_subject.cms_owner_num INNER JOIN codingmon_subject ON codingmon_member_subject.cms_code=codingmon_subject.cs_code;

SELECT * FROM codingmon_member 
INNER JOIN codingmon_member_info ON codingmon_member.cm_num=codingmon_member_info.cmi_owner_num 
limit 0 , 5;

-- WHERE cm_num in 
-- (SELECT cij_owner_num FROM codingmon_info_job WHERE cij_code = 105 OR cij_code = 3);


SELECT cij_owner_num FROM codingmon_info_job WHERE cij_code = 105 OR cij_code = 3;

SELECT * FROM codingmon_member_subject WHERE cms_category=0;
SELECT DISTINCT cms_owner_num FROM codingmon_member_subject WHERE cms_category=0 AND cms_code IN(1,3, 24, 33);
SELECT * FROM codingmon_info_job WHERE cij_code = 105 OR cij_code = 3;

-- 10대
SELECT * FROM codingmon_member_info WHERE cmi_age;
SELECT if(date_format(now(),'%Y')-substring(cmi_age,1,4) between 20 and 29, 1, 0)  FROM codingmon_member_info;

SELECT * FROM codingmon_member_info;
SELECT * FROM codingmon_member_info WHERE cmi_age BETWEEN '19901219' AND '19991219' OR cmi_age BETWEEN '19801219' AND '19891219';

