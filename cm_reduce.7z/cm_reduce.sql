-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema codingmonDB
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema codingmonDB
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `codingmonDB` DEFAULT CHARACTER SET utf8 ;
USE `codingmonDB` ;

-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_member`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_member` (
  `cm_num` INT NOT NULL AUTO_INCREMENT,
  `cm_email` VARCHAR(50) NOT NULL,
  `cm_pw` VARCHAR(255) NOT NULL,
  `cm_name` VARCHAR(30) NOT NULL,
  `cm_phone` VARCHAR(15) NULL,
  `cm_addr` VARCHAR(255) NULL,
  `cm_regdate` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `cm_join` CHAR(1) NULL DEFAULT 'Y',
  `cm_salt` INT NULL,
  PRIMARY KEY (`cm_num`),
  UNIQUE INDEX `cm_email_UNIQUE` (`cm_email` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_member_info`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_member_info` (
  `cmi_owner_num` INT NOT NULL,
  `cmi_title` VARCHAR(100) NOT NULL,
  `cmi_intro` TEXT NULL,
  `cmi_private` CHAR(1) NOT NULL DEFAULT 'N',
  `cmi_gender` VARCHAR(10) NOT NULL DEFAULT 'Male',
  `cmi_age` INT NULL,
  `cmi_career` TEXT NULL,
  `cmi_achieve` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`cmi_owner_num`),
  INDEX `cmi_owner_num_idx` (`cmi_owner_num` ASC),
  CONSTRAINT `cmi_owner_num`
    FOREIGN KEY (`cmi_owner_num`)
    REFERENCES `codingmonDB`.`codingmon_member` (`cm_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_board_recruit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_board_recruit` (
  `cbr_num` INT NOT NULL AUTO_INCREMENT,
  `cbr_title` VARCHAR(100) NOT NULL,
  `cbr_writer` VARCHAR(45) NOT NULL,
  `cbr_writer_num` INT NOT NULL,
  `cbr_content` TEXT NULL,
  `cbr_regdate` TIMESTAMP NULL DEFAULT now(),
  `cbr_pay` DECIMAL NULL,
  `cbr_date_from` TIMESTAMP NULL,
  `cbr_date_to` TIMESTAMP NULL,
  `cbr_deadline` TIMESTAMP NULL,
  PRIMARY KEY (`cbr_num`),
  INDEX `cbr_writer_num_idx` (`cbr_writer_num` ASC),
  CONSTRAINT `cbr_writer_num`
    FOREIGN KEY (`cbr_writer_num`)
    REFERENCES `codingmonDB`.`codingmon_member` (`cm_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_passcode`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_passcode` (
  `cpc_email` VARCHAR(50) NOT NULL,
  `cpc_code` CHAR(5) NOT NULL,
  PRIMARY KEY (`cpc_email`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_board_qna`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_board_qna` (
  `cbq_num` INT NOT NULL AUTO_INCREMENT,
  `cbq_writer_num` INT NOT NULL,
  `cbq_writer_name` VARCHAR(45) NOT NULL,
  `cbq_title` VARCHAR(100) NOT NULL,
  `cbq_content` TEXT NULL,
  `cbq_re_ref` INT NOT NULL,
  `cbq_re_lev` INT NOT NULL,
  `cbq_re_seq` INT NOT NULL,
  `cbq_readcount` INT NULL DEFAULT 0,
  `cbq_regdate` TIMESTAMP NULL DEFAULT now(),
  `cbq_file` VARCHAR(100) NULL,
  `cbq_file_origin` VARCHAR(100) NULL,
  `cbq_up` INT NULL DEFAULT 0,
  `cbq_delete` CHAR(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`cbq_num`),
  INDEX `cbq_writer_num_idx` (`cbq_writer_num` ASC),
  CONSTRAINT `cbq_writer_num`
    FOREIGN KEY (`cbq_writer_num`)
    REFERENCES `codingmonDB`.`codingmon_member` (`cm_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_comment_recruit`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_comment_recruit` (
  `ccr_num` INT NOT NULL AUTO_INCREMENT,
  `ccr_board_num` INT NOT NULL,
  `ccr_writer_num` INT NOT NULL,
  `ccr_writer_name` VARCHAR(40) NOT NULL,
  `ccr_content` TEXT NULL,
  `ccr_regdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ccr_delete` CHAR(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ccr_num`),
  INDEX `ccr_board_num_idx` (`ccr_board_num` ASC),
  CONSTRAINT `ccr_board_num`
    FOREIGN KEY (`ccr_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_recruit` (`cbr_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_comment_qna`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_comment_qna` (
  `ccq_num` INT NOT NULL AUTO_INCREMENT,
  `ccq_board_num` INT NOT NULL,
  `ccq_writer_num` INT NOT NULL,
  `ccq_writer_name` VARCHAR(45) NOT NULL,
  `ccq_content` TEXT NULL,
  `ccq_regdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ccq_delete` CHAR(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`ccq_num`),
  INDEX `ccq_board_num_idx` (`ccq_board_num` ASC),
  CONSTRAINT `ccq_board_num`
    FOREIGN KEY (`ccq_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_qna` (`cbq_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_subject`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_subject` (
  `cs_code` INT NOT NULL,
  `cs_name` VARCHAR(100) NOT NULL,
  `cs_category` INT NOT NULL,
  PRIMARY KEY (`cs_code`),
  UNIQUE INDEX `cs_name_UNIQUE` (`cs_name` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_member_subject`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_member_subject` (
  `cms_code` INT NOT NULL,
  `cms_owner_num` INT NOT NULL,
  `cms_category` INT NOT NULL DEFAULT 0,
  INDEX `cms_code_idx` (`cms_code` ASC),
  INDEX `cms_owner_num_idx` (`cms_owner_num` ASC),
  CONSTRAINT `cms_code`
    FOREIGN KEY (`cms_code`)
    REFERENCES `codingmonDB`.`codingmon_subject` (`cs_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `cms_owner_num`
    FOREIGN KEY (`cms_owner_num`)
    REFERENCES `codingmonDB`.`codingmon_member_info` (`cmi_owner_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_region` (
  `cr_code` INT NOT NULL,
  `cr_name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`cr_code`),
  UNIQUE INDEX `cr_name_UNIQUE` (`cr_name` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_member_region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_member_region` (
  `cmr_code` INT NOT NULL,
  `cmr_owner_num` INT NOT NULL,
  INDEX `cmr_code_idx` (`cmr_code` ASC),
  INDEX `cmr_owner_num_idx` (`cmr_owner_num` ASC),
  CONSTRAINT `cmr_code`
    FOREIGN KEY (`cmr_code`)
    REFERENCES `codingmonDB`.`codingmon_region` (`cr_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `cmr_owner_num`
    FOREIGN KEY (`cmr_owner_num`)
    REFERENCES `codingmonDB`.`codingmon_member_info` (`cmi_owner_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`coding_recruit_region`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`coding_recruit_region` (
  `crr_code` INT NOT NULL,
  `crr_board_num` INT NOT NULL,
  INDEX `crr_code_idx` (`crr_code` ASC),
  INDEX `crr_board_num_idx` (`crr_board_num` ASC),
  CONSTRAINT `crr_code`
    FOREIGN KEY (`crr_code`)
    REFERENCES `codingmonDB`.`codingmon_region` (`cr_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `crr_board_num`
    FOREIGN KEY (`crr_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_recruit` (`cbr_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_recruit_subject`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_recruit_subject` (
  `crs_code` INT NOT NULL,
  `crs_board_num` INT NOT NULL,
  INDEX `crs_code_idx` (`crs_code` ASC),
  INDEX `crs_board_num_idx` (`crs_board_num` ASC),
  CONSTRAINT `crs_code`
    FOREIGN KEY (`crs_code`)
    REFERENCES `codingmonDB`.`codingmon_subject` (`cs_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `crs_board_num`
    FOREIGN KEY (`crs_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_recruit` (`cbr_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_payment_method`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_payment_method` (
  `cpm_code` INT NOT NULL,
  `cpm_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`cpm_code`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_recruit_payment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_recruit_payment` (
  `crp_code` INT NOT NULL,
  `crp_board_num` INT NOT NULL,
  INDEX `crp_code_idx` (`crp_code` ASC),
  INDEX `crp_board_num_idx` (`crp_board_num` ASC),
  CONSTRAINT `crp_code`
    FOREIGN KEY (`crp_code`)
    REFERENCES `codingmonDB`.`codingmon_payment_method` (`cpm_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `crp_board_num`
    FOREIGN KEY (`crp_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_recruit` (`cbr_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_job`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_job` (
  `cj_code` INT NOT NULL,
  `cj_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`cj_code`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_info_job`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_info_job` (
  `cij_code` INT NOT NULL,
  `cij_owner_num` INT NOT NULL,
  INDEX `cij_code_idx` (`cij_code` ASC),
  INDEX `cij_owner_num_idx` (`cij_owner_num` ASC),
  CONSTRAINT `cij_code`
    FOREIGN KEY (`cij_code`)
    REFERENCES `codingmonDB`.`codingmon_job` (`cj_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `cij_owner_num`
    FOREIGN KEY (`cij_owner_num`)
    REFERENCES `codingmonDB`.`codingmon_member_info` (`cmi_owner_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_recruit_job`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_recruit_job` (
  `crj_code` INT NOT NULL,
  `crj_board_num` INT NOT NULL,
  INDEX `crj_code_idx` (`crj_code` ASC),
  INDEX `crj_board_num_idx` (`crj_board_num` ASC),
  CONSTRAINT `crj_code`
    FOREIGN KEY (`crj_code`)
    REFERENCES `codingmonDB`.`codingmon_job` (`cj_code`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `crj_board_num`
    FOREIGN KEY (`crj_board_num`)
    REFERENCES `codingmonDB`.`codingmon_board_recruit` (`cbr_num`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `codingmonDB`.`codingmon_member_profile`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `codingmonDB`.`codingmon_member_profile` (
  `cmp_owner_num` INT NOT NULL,
  `cmp_image` VARCHAR(255) NOT NULL,
  `cmp_image_origin` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`cmp_owner_num`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
